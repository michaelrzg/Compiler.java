class NumberNode extends Node {
    int value;
    
    public NumberNode(int value) {
        this.value = value;
    }
}