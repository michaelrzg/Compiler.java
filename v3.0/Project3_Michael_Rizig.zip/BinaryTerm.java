class BinaryTerm extends Term{
    public BinaryTerm(Node term_node, Node factor){
        super(term_node,factor);
    }
}