class NegFactor extends Factor{

    public NegFactor(Node terminal, Node nonterminal) {
        super(terminal, nonterminal);
    }
    
}