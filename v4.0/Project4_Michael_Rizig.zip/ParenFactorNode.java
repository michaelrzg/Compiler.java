class ParenFactorNode extends Factor {
     public ParenFactorNode(Node terminal, Node nonterminal) {
        super(terminal, nonterminal);
    }
    
}