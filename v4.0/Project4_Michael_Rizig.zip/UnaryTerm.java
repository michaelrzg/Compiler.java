class UnaryTerm extends Term{
    public UnaryTerm(Node term_node, Node factor){
        super(term_node,factor);
    }
}